export default function AppTest() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-purple-50 to-indigo-50 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-8 text-center">
          <h1 className="text-purple-900 mb-4">MuseForge Test</h1>
          <p className="text-purple-600">If you can see this, the basic app is working!</p>
        </div>
      </div>
    </div>
  );
}
