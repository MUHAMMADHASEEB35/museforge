import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { Label } from './ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Copy, Download, RefreshCw, Wand2, MessageSquare, Bot, Cpu, Zap, Star, Trash2, Share2, Clock, History, Mic, MicOff } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import type { SavedPrompt } from '../App';
import { Badge } from './ui/badge';

interface PromptGeneratorProps {
  language: string;
  currentView: 'generator' | 'history' | 'favorites';
  savedPrompts: SavedPrompt[];
  onAddPrompt: (prompt: SavedPrompt) => void;
  onToggleFavorite: (id: string) => void;
  onDeletePrompt: (id: string) => void;
}

export function PromptGenerator({ 
  language, 
  currentView, 
  savedPrompts, 
  onAddPrompt,
  onToggleFavorite,
  onDeletePrompt
}: PromptGeneratorProps) {
  const [selectedPlatform, setSelectedPlatform] = useState('');
  const [topic, setTopic] = useState('');
  const [tone, setTone] = useState('professional');
  const [promptType, setPromptType] = useState('general');
  const [context, setContext] = useState('');
  const [outputLength, setOutputLength] = useState('medium');
  const [generatedPrompt, setGeneratedPrompt] = useState('');
  const [currentPromptId, setCurrentPromptId] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);

  const platforms = [
    { id: 'chatgpt', name: 'ChatGPT', icon: MessageSquare },
    { id: 'gemini', name: 'Gemini', icon: Zap },
    { id: 'copilot', name: 'Copilot', icon: Bot },
    { id: 'deepseek', name: 'DeepSeek', icon: Cpu }
  ];

  const platformNames = {
    chatgpt: 'ChatGPT',
    gemini: 'Gemini',
    copilot: 'Copilot',
    deepseek: 'DeepSeek'
  };

  const generatePrompt = () => {
    if (!selectedPlatform) {
      toast.error('Please select an AI platform first');
      return;
    }
    if (!topic.trim()) {
      toast.error('Please enter a topic');
      return;
    }

    // Generate a comprehensive prompt based on inputs
    let prompt = '';
    
    if (promptType === 'creative') {
      prompt = `Create a ${tone} and creative response about "${topic}". `;
    } else if (promptType === 'analytical') {
      prompt = `Provide a detailed ${tone} analysis of "${topic}". `;
    } else if (promptType === 'instructional') {
      prompt = `Explain "${topic}" in a ${tone} and instructional manner. `;
    } else {
      prompt = `In a ${tone} tone, discuss "${topic}". `;
    }

    if (context.trim()) {
      prompt += `\n\nContext: ${context}\n\n`;
    }

    // Add length preference
    if (outputLength === 'short') {
      prompt += `Keep the response concise and to the point (2-3 paragraphs). `;
    } else if (outputLength === 'long') {
      prompt += `Provide a comprehensive and detailed response with examples. `;
    } else {
      prompt += `Provide a well-structured response. `;
    }

    prompt += `Please structure your response clearly and provide comprehensive information.`;

    if (language !== 'English') {
      prompt += ` Respond in ${language}.`;
    }

    const promptId = Date.now().toString();
    setGeneratedPrompt(prompt);
    setCurrentPromptId(promptId);

    // Add to history
    const newPrompt: SavedPrompt = {
      id: promptId,
      platform: selectedPlatform,
      topic,
      prompt,
      timestamp: new Date(),
      isFavorite: false
    };
    onAddPrompt(newPrompt);

    toast.success('Prompt generated successfully!');
  };

  const copyToClipboard = (text: string) => {
    // Try modern clipboard API first
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        toast.success('Copied to clipboard!');
      }).catch(() => {
        // Fallback to older method
        fallbackCopyToClipboard(text);
      });
    } else {
      // Fallback for older browsers or when clipboard API is not available
      fallbackCopyToClipboard(text);
    }
  };

  const fallbackCopyToClipboard = (text: string) => {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.select();
    try {
      document.execCommand('copy');
      toast.success('Copied to clipboard!');
    } catch (err) {
      toast.error('Failed to copy');
    }
    document.body.removeChild(textArea);
  };

  const downloadPrompt = (text: string, platform: string) => {
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `prompt-${platform}-${Date.now()}.txt`;
    a.click();
    toast.success('Prompt downloaded!');
  };

  const sharePrompt = (text: string) => {
    if (navigator.share) {
      navigator.share({
        title: 'AI Prompt',
        text: text,
      }).then(() => {
        toast.success('Shared successfully!');
      }).catch(() => {
        copyToClipboard(text);
      });
    } else {
      copyToClipboard(text);
    }
  };

  const getSelectedPlatformIcon = () => {
    const platform = platforms.find(p => p.id === selectedPlatform);
    if (!platform) return null;
    const Icon = platform.icon;
    return <Icon className="w-4 h-4" />;
  };

  const formatTimestamp = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  // Voice recognition functionality
  const toggleVoiceInput = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  const startListening = () => {
    // Check if browser supports speech recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      toast.error('Speech recognition is not supported in your browser');
      return;
    }

    const recognitionInstance = new SpeechRecognition();
    recognitionInstance.continuous = true;
    recognitionInstance.interimResults = true;
    recognitionInstance.lang = language === 'English' ? 'en-US' : 
                                language === 'Spanish' ? 'es-ES' :
                                language === 'French' ? 'fr-FR' :
                                language === 'German' ? 'de-DE' :
                                language === 'Chinese' ? 'zh-CN' :
                                language === 'Japanese' ? 'ja-JP' :
                                'en-US';

    recognitionInstance.onstart = () => {
      setIsListening(true);
      toast.success('Listening... Speak now');
    };

    recognitionInstance.onresult = (event: any) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript + ' ';
        } else {
          interimTranscript += transcript;
        }
      }

      if (finalTranscript) {
        setContext(prev => {
          const newContext = prev ? `${prev} ${finalTranscript}` : finalTranscript;
          return newContext.trim();
        });
      }
    };

    recognitionInstance.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      setIsListening(false);
      
      if (event.error === 'no-speech') {
        toast.error('No speech detected. Please try again.');
      } else if (event.error === 'not-allowed') {
        toast.error('Microphone access denied. Please allow microphone permissions.');
      } else {
        toast.error('Voice recognition error. Please try again.');
      }
    };

    recognitionInstance.onend = () => {
      setIsListening(false);
    };

    recognitionInstance.start();
    setRecognition(recognitionInstance);
  };

  const stopListening = () => {
    if (recognition) {
      recognition.stop();
      setIsListening(false);
      toast.info('Stopped listening');
    }
  };

  // Render History View
  if (currentView === 'history') {
    return (
      <div className="max-w-4xl mx-auto space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
          <div>
            <h2 className="text-purple-900">Prompt History</h2>
            <p className="text-sm text-purple-600">View and manage your generated prompts</p>
          </div>
          <Badge variant="secondary" className="bg-purple-100 text-purple-700 w-fit">
            {savedPrompts.length} Prompts
          </Badge>
        </div>

        {savedPrompts.length === 0 ? (
          <Card className="p-6 sm:p-8 bg-white/80 backdrop-blur-sm border-purple-200">
            <div className="text-center space-y-4">
              <div className="inline-flex p-4 bg-purple-100 rounded-full">
                <History className="w-8 h-8 sm:w-12 sm:h-12 text-purple-600" />
              </div>
              <h3 className="text-purple-900">No History Yet</h3>
              <p className="text-sm sm:text-base text-purple-600">
                Your generated prompts will appear here
              </p>
            </div>
          </Card>
        ) : (
          <div className="space-y-4">
            {savedPrompts.map((item) => (
              <Card key={item.id} className="p-4 bg-white/80 backdrop-blur-sm border-purple-200">
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2 sm:gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <Badge variant="outline" className="border-purple-300 text-purple-700 text-xs">
                          {platformNames[item.platform as keyof typeof platformNames]}
                        </Badge>
                        <span className="text-xs sm:text-sm text-purple-600 flex items-center gap-1">
                          <Clock className="w-3 h-3 flex-shrink-0" />
                          <span className="truncate">{formatTimestamp(item.timestamp)}</span>
                        </span>
                      </div>
                      <h4 className="text-sm sm:text-base text-purple-900 break-words">{item.topic}</h4>
                    </div>
                    <div className="flex gap-1 flex-shrink-0">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onToggleFavorite(item.id)}
                        className={`p-2 ${item.isFavorite ? 'text-yellow-600' : 'text-purple-600'}`}
                      >
                        <Star className={`w-4 h-4 ${item.isFavorite ? 'fill-yellow-600' : ''}`} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onDeletePrompt(item.id)}
                        className="text-red-600 p-2"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-lg p-3 border border-purple-200">
                    <p className="text-xs sm:text-sm text-purple-900 line-clamp-3 break-words">{item.prompt}</p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(item.prompt)}
                      className="border-purple-200 text-purple-700 hover:bg-purple-50 text-xs sm:text-sm"
                    >
                      <Copy className="w-3 h-3 mr-1" />
                      Copy
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => downloadPrompt(item.prompt, item.platform)}
                      className="border-purple-200 text-purple-700 hover:bg-purple-50 text-xs sm:text-sm"
                    >
                      <Download className="w-3 h-3 mr-1" />
                      Download
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => sharePrompt(item.prompt)}
                      className="border-purple-200 text-purple-700 hover:bg-purple-50 text-xs sm:text-sm"
                    >
                      <Share2 className="w-3 h-3 mr-1" />
                      Share
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  }

  // Render Favorites View
  if (currentView === 'favorites') {
    const favoritePrompts = savedPrompts.filter(p => p.isFavorite);

    return (
      <div className="max-w-4xl mx-auto space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
          <div>
            <h2 className="text-purple-900">Favorite Prompts</h2>
            <p className="text-sm text-purple-600">Your starred prompts for quick access</p>
          </div>
          <Badge variant="secondary" className="bg-purple-100 text-purple-700 w-fit">
            {favoritePrompts.length} Favorites
          </Badge>
        </div>

        {favoritePrompts.length === 0 ? (
          <Card className="p-6 sm:p-8 bg-white/80 backdrop-blur-sm border-purple-200">
            <div className="text-center space-y-4">
              <div className="inline-flex p-4 bg-purple-100 rounded-full">
                <Star className="w-8 h-8 sm:w-12 sm:h-12 text-purple-600" />
              </div>
              <h3 className="text-purple-900">No Favorites Yet</h3>
              <p className="text-sm sm:text-base text-purple-600">
                Star prompts from your history to save them here
              </p>
            </div>
          </Card>
        ) : (
          <div className="space-y-4">
            {favoritePrompts.map((item) => (
              <Card key={item.id} className="p-4 bg-white/80 backdrop-blur-sm border-purple-200 border-l-4 border-l-yellow-400">
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2 sm:gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <Badge variant="outline" className="border-purple-300 text-purple-700 text-xs">
                          {platformNames[item.platform as keyof typeof platformNames]}
                        </Badge>
                        <span className="text-xs sm:text-sm text-purple-600 flex items-center gap-1">
                          <Clock className="w-3 h-3 flex-shrink-0" />
                          <span className="truncate">{formatTimestamp(item.timestamp)}</span>
                        </span>
                      </div>
                      <h4 className="text-sm sm:text-base text-purple-900 break-words">{item.topic}</h4>
                    </div>
                    <div className="flex gap-1 flex-shrink-0">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onToggleFavorite(item.id)}
                        className="text-yellow-600 p-2"
                      >
                        <Star className="w-4 h-4 fill-yellow-600" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onDeletePrompt(item.id)}
                        className="text-red-600 p-2"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-lg p-3 border border-purple-200">
                    <p className="text-xs sm:text-sm text-purple-900 break-words">{item.prompt}</p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(item.prompt)}
                      className="border-purple-200 text-purple-700 hover:bg-purple-50 text-xs sm:text-sm"
                    >
                      <Copy className="w-3 h-3 mr-1" />
                      Copy
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => downloadPrompt(item.prompt, item.platform)}
                      className="border-purple-200 text-purple-700 hover:bg-purple-50 text-xs sm:text-sm"
                    >
                      <Download className="w-3 h-3 mr-1" />
                      Download
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => sharePrompt(item.prompt)}
                      className="border-purple-200 text-purple-700 hover:bg-purple-50 text-xs sm:text-sm"
                    >
                      <Share2 className="w-3 h-3 mr-1" />
                      Share
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  }

  // Render Generator View (default)
  return (
    <div className="max-w-4xl mx-auto space-y-4 sm:space-y-6">
      <Card className="p-4 sm:p-6 bg-white/80 backdrop-blur-sm border-purple-200">
        <div className="flex items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
          <div className="p-1.5 sm:p-2 bg-gradient-to-br from-purple-600 to-indigo-600 rounded-lg flex-shrink-0">
            <Wand2 className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
          </div>
          <div className="min-w-0">
            <h2 className="text-purple-900 truncate">Generate AI Prompt</h2>
            <p className="text-xs sm:text-sm text-purple-600 hidden sm:block">Fill in the details to create an optimized prompt</p>
          </div>
        </div>

        <div className="space-y-4 sm:space-y-5">
          <div className="space-y-2">
            <Label htmlFor="platform" className="text-purple-900 text-sm sm:text-base">Select AI Platform *</Label>
            <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
              <SelectTrigger className="border-purple-200 focus:ring-purple-500">
                <SelectValue placeholder="Choose your AI platform">
                  {selectedPlatform && (
                    <div className="flex items-center gap-2">
                      {getSelectedPlatformIcon()}
                      <span className="text-sm sm:text-base">{platformNames[selectedPlatform as keyof typeof platformNames]}</span>
                    </div>
                  )}
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                {platforms.map((platform) => {
                  const Icon = platform.icon;
                  return (
                    <SelectItem key={platform.id} value={platform.id}>
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4" />
                        <span>{platform.name}</span>
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
            <div className="space-y-2">
              <Label htmlFor="topic" className="text-purple-900 text-sm sm:text-base">Topic / Subject *</Label>
              <Input
                id="topic"
                placeholder="e.g., Machine Learning, Recipe..."
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="border-purple-200 focus:ring-purple-500 text-sm sm:text-base"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="tone" className="text-purple-900 text-sm sm:text-base">Tone</Label>
              <Select value={tone} onValueChange={setTone}>
                <SelectTrigger className="border-purple-200 focus:ring-purple-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="casual">Casual</SelectItem>
                  <SelectItem value="friendly">Friendly</SelectItem>
                  <SelectItem value="formal">Formal</SelectItem>
                  <SelectItem value="technical">Technical</SelectItem>
                  <SelectItem value="creative">Creative</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
            <div className="space-y-2">
              <Label htmlFor="promptType" className="text-purple-900 text-sm sm:text-base">Prompt Type</Label>
              <Select value={promptType} onValueChange={setPromptType}>
                <SelectTrigger className="border-purple-200 focus:ring-purple-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">General Query</SelectItem>
                  <SelectItem value="creative">Creative Writing</SelectItem>
                  <SelectItem value="analytical">Analytical / Research</SelectItem>
                  <SelectItem value="instructional">Instructional / How-to</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="outputLength" className="text-purple-900 text-sm sm:text-base">Output Length</Label>
              <Select value={outputLength} onValueChange={setOutputLength}>
                <SelectTrigger className="border-purple-200 focus:ring-purple-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="short">Short (2-3 paragraphs)</SelectItem>
                  <SelectItem value="medium">Medium (Standard)</SelectItem>
                  <SelectItem value="long">Long (Comprehensive)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="context" className="text-purple-900 text-sm sm:text-base">Additional Context (Optional)</Label>
            <div className="relative">
              <Textarea
                id="context"
                placeholder="Add any additional context, requirements, or specific details..."
                value={context}
                onChange={(e) => setContext(e.target.value)}
                className="min-h-20 sm:min-h-24 border-purple-200 focus:ring-purple-500 text-sm sm:text-base pr-12"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={toggleVoiceInput}
                className={`absolute right-2 top-2 p-2 transition-all duration-200 ${
                  isListening 
                    ? 'text-red-600 bg-red-50 hover:bg-red-100 animate-pulse' 
                    : 'text-purple-600 hover:bg-purple-50'
                }`}
                title={isListening ? "Stop recording" : "Start voice input"}
              >
                {isListening ? (
                  <MicOff className="w-4 h-4 sm:w-5 sm:h-5" />
                ) : (
                  <Mic className="w-4 h-4 sm:w-5 sm:h-5" />
                )}
              </Button>
            </div>
            {isListening && (
              <div className="flex items-center gap-2 text-red-600 animate-pulse">
                <div className="w-2 h-2 bg-red-600 rounded-full"></div>
                <p className="text-xs sm:text-sm">Recording... Click the microphone to stop</p>
              </div>
            )}
          </div>

          <Button
            onClick={generatePrompt}
            className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-lg text-sm sm:text-base py-5 sm:py-6"
          >
            <Wand2 className="w-4 h-4 mr-2" />
            Generate Prompt
          </Button>
        </div>
      </Card>

      {generatedPrompt && (
        <Card className="p-4 sm:p-6 bg-white/80 backdrop-blur-sm border-purple-200">
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-purple-900">Generated Prompt</h3>
                <Badge variant="secondary" className="bg-green-100 text-green-700 text-xs">
                  {generatedPrompt.length} chars
                </Badge>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onToggleFavorite(currentPromptId)}
                  className="text-purple-700 hover:text-yellow-600 p-2"
                >
                  <Star className={`w-4 h-4 ${savedPrompts.find(p => p.id === currentPromptId)?.isFavorite ? 'fill-yellow-600 text-yellow-600' : ''}`} />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(generatedPrompt)}
                  className="border-purple-200 text-purple-700 hover:bg-purple-50 text-xs sm:text-sm"
                >
                  <Copy className="w-3 h-3 sm:w-4 sm:h-4 sm:mr-2" />
                  <span className="hidden sm:inline">Copy</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => downloadPrompt(generatedPrompt, selectedPlatform)}
                  className="border-purple-200 text-purple-700 hover:bg-purple-50 text-xs sm:text-sm"
                >
                  <Download className="w-3 h-3 sm:w-4 sm:h-4 sm:mr-2" />
                  <span className="hidden sm:inline">Download</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => sharePrompt(generatedPrompt)}
                  className="border-purple-200 text-purple-700 hover:bg-purple-50 text-xs sm:text-sm"
                >
                  <Share2 className="w-3 h-3 sm:w-4 sm:h-4 sm:mr-2" />
                  <span className="hidden sm:inline">Share</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={generatePrompt}
                  className="border-purple-200 text-purple-700 hover:bg-purple-50 text-xs sm:text-sm"
                >
                  <RefreshCw className="w-3 h-3 sm:w-4 sm:h-4 sm:mr-2" />
                  <span className="hidden sm:inline">Regenerate</span>
                </Button>
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-lg p-3 sm:p-4 border border-purple-200">
              <pre className="whitespace-pre-wrap text-xs sm:text-sm text-purple-900 break-words">{generatedPrompt}</pre>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 sm:p-4">
              <p className="text-xs sm:text-sm text-blue-800">
                <strong>Tip:</strong> Copy this prompt and paste it into {platformNames[selectedPlatform as keyof typeof platformNames]} to get the best results. You can modify it further based on your specific needs.
              </p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}