import { Heart, Github, Mail, Twitter, Linkedin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-white/80 backdrop-blur-lg border-t border-purple-200 mt-auto">
      <div className="container mx-auto px-4 py-6 sm:py-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-4 sm:mb-6">
          {/* About Section */}
          <div>
            <h3 className="text-sm sm:text-base text-purple-900 mb-2 sm:mb-3">About MuseForge</h3>
            <p className="text-xs sm:text-sm text-purple-600 mb-3 sm:mb-4">
              Create perfect prompts for any AI platform with ease. MuseForge helps you craft optimized prompts for ChatGPT, Gemini, Copilot, and DeepSeek.
            </p>
            <div className="flex items-center gap-2 text-purple-700 text-xs sm:text-sm">
              <span>Made with</span>
              <Heart className="w-3 h-3 sm:w-4 sm:h-4 fill-purple-600 text-purple-600 flex-shrink-0" />
              <span>for AI Enthusiasts</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm sm:text-base text-purple-900 mb-2 sm:mb-3">Quick Links</h3>
            <ul className="space-y-1.5 sm:space-y-2">
              <li>
                <a href="#" className="text-xs sm:text-sm text-purple-600 hover:text-purple-800 transition-colors">
                  How to Use
                </a>
              </li>
              <li>
                <a href="#" className="text-xs sm:text-sm text-purple-600 hover:text-purple-800 transition-colors">
                  Prompt Templates
                </a>
              </li>
              <li>
                <a href="#" className="text-xs sm:text-sm text-purple-600 hover:text-purple-800 transition-colors">
                  Best Practices
                </a>
              </li>
              <li>
                <a href="#" className="text-xs sm:text-sm text-purple-600 hover:text-purple-800 transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-xs sm:text-sm text-purple-600 hover:text-purple-800 transition-colors">
                  Terms of Service
                </a>
              </li>
            </ul>
          </div>

          {/* Connect */}
          <div className="sm:col-span-2 lg:col-span-1">
            <h3 className="text-sm sm:text-base text-purple-900 mb-2 sm:mb-3">Connect With Us</h3>
            <p className="text-xs sm:text-sm text-purple-600 mb-3 sm:mb-4">
              Follow us on social media for tips, updates, and AI prompt inspiration.
            </p>
            <div className="flex gap-2 sm:gap-3">
              <a 
                href="#" 
                className="p-1.5 sm:p-2 bg-purple-100 hover:bg-purple-200 text-purple-600 hover:text-purple-800 rounded-lg transition-all"
                aria-label="GitHub"
              >
                <Github className="w-4 h-4 sm:w-5 sm:h-5" />
              </a>
              <a 
                href="#" 
                className="p-1.5 sm:p-2 bg-purple-100 hover:bg-purple-200 text-purple-600 hover:text-purple-800 rounded-lg transition-all"
                aria-label="Twitter"
              >
                <Twitter className="w-4 h-4 sm:w-5 sm:h-5" />
              </a>
              <a 
                href="#" 
                className="p-1.5 sm:p-2 bg-purple-100 hover:bg-purple-200 text-purple-600 hover:text-purple-800 rounded-lg transition-all"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-4 h-4 sm:w-5 sm:h-5" />
              </a>
              <a 
                href="#" 
                className="p-1.5 sm:p-2 bg-purple-100 hover:bg-purple-200 text-purple-600 hover:text-purple-800 rounded-lg transition-all"
                aria-label="Email"
              >
                <Mail className="w-4 h-4 sm:w-5 sm:h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-4 sm:pt-6 border-t border-purple-200 flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4">
          <div className="text-xs sm:text-sm text-purple-600 text-center sm:text-left">
            © 2024 MuseForge. All rights reserved.
          </div>
          <div className="flex flex-wrap justify-center gap-3 sm:gap-6 text-xs sm:text-sm">
            <a href="#" className="text-purple-600 hover:text-purple-800 transition-colors">
              Help Center
            </a>
            <a href="#" className="text-purple-600 hover:text-purple-800 transition-colors">
              Contact Support
            </a>
            <a href="#" className="text-purple-600 hover:text-purple-800 transition-colors whitespace-nowrap">
              API Docs
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
