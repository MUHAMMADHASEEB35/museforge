import { Wand2, History, Star, BookOpen, Lightbulb, TrendingUp, X } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import type { SavedPrompt } from '../App';

interface SidebarProps {
  currentView: 'generator' | 'history' | 'favorites';
  onViewChange: (view: 'generator' | 'history' | 'favorites') => void;
  savedPrompts: SavedPrompt[];
  onToggleFavorite: (id: string) => void;
  onDeletePrompt: (id: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ currentView, onViewChange, savedPrompts, isOpen, onClose }: SidebarProps) {
  const favoriteCount = savedPrompts.filter(p => p.isFavorite).length;
  const historyCount = savedPrompts.length;

  const quickTemplates = [
    {
      id: 'blog',
      title: 'Blog Writing',
      icon: BookOpen,
      description: 'SEO-optimized blog posts'
    },
    {
      id: 'creative',
      title: 'Creative Story',
      icon: Lightbulb,
      description: 'Fiction & storytelling'
    },
    {
      id: 'marketing',
      title: 'Marketing Copy',
      icon: TrendingUp,
      description: 'Ads & sales content'
    }
  ];

  return (
    <>
      {/* Sidebar */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-40
        w-80 bg-white/60 backdrop-blur-sm border-r border-purple-200 
        overflow-y-auto transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="p-4 sm:p-6 space-y-6">
          {/* Mobile Close Button */}
          <div className="flex items-center justify-between lg:hidden mb-4">
            <h2 className="text-purple-900">Menu</h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-purple-600 hover:bg-purple-100"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="text-purple-900 mb-3">Menu</h3>
            <div className="space-y-2">
              <Button
                variant={currentView === 'generator' ? 'default' : 'ghost'}
                className={`w-full justify-start text-sm sm:text-base ${
                  currentView === 'generator'
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white'
                    : 'text-purple-700 hover:text-purple-900 hover:bg-purple-100'
                }`}
                onClick={() => onViewChange('generator')}
              >
                <Wand2 className="w-4 h-4 mr-2 flex-shrink-0" />
                <span className="truncate">Prompt Generator</span>
              </Button>
              <Button
                variant={currentView === 'history' ? 'default' : 'ghost'}
                className={`w-full justify-start text-sm sm:text-base ${
                  currentView === 'history'
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white'
                    : 'text-purple-700 hover:text-purple-900 hover:bg-purple-100'
                }`}
                onClick={() => onViewChange('history')}
              >
                <History className="w-4 h-4 mr-2 flex-shrink-0" />
                <span className="truncate">History</span>
                {historyCount > 0 && (
                  <Badge className="ml-auto bg-purple-100 text-purple-700 text-xs">
                    {historyCount}
                  </Badge>
                )}
              </Button>
              <Button
                variant={currentView === 'favorites' ? 'default' : 'ghost'}
                className={`w-full justify-start text-sm sm:text-base ${
                  currentView === 'favorites'
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white'
                    : 'text-purple-700 hover:text-purple-900 hover:bg-purple-100'
                }`}
                onClick={() => onViewChange('favorites')}
              >
                <Star className="w-4 h-4 mr-2 flex-shrink-0" />
                <span className="truncate">Favorites</span>
                {favoriteCount > 0 && (
                  <Badge className="ml-auto bg-purple-100 text-purple-700 text-xs">
                    {favoriteCount}
                  </Badge>
                )}
              </Button>
            </div>
          </div>

          {/* Quick Templates */}
          <div className="pt-4 border-t border-purple-200">
            <h3 className="text-purple-900 mb-3">Quick Templates</h3>
            <div className="space-y-3">
              {quickTemplates.map((template) => {
                const Icon = template.icon;
                return (
                  <Card
                    key={template.id}
                    className="p-3 cursor-pointer transition-all hover:shadow-md bg-white hover:bg-purple-50 border-purple-100"
                  >
                    <div className="flex items-start gap-2 sm:gap-3">
                      <div className="p-1.5 sm:p-2 bg-gradient-to-br from-purple-600 to-indigo-600 rounded-lg flex-shrink-0">
                        <Icon className="w-3 h-3 sm:w-4 sm:h-4 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm sm:text-base text-purple-900 truncate">{template.title}</div>
                        <p className="text-xs text-purple-600 truncate">
                          {template.description}
                        </p>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Tips Section */}
          <div className="pt-4 border-t border-purple-200">
            <Card className="p-3 sm:p-4 bg-gradient-to-br from-indigo-50 to-purple-50 border-purple-200">
              <div className="flex items-start gap-2 sm:gap-3">
                <Lightbulb className="w-4 h-4 sm:w-5 sm:h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm sm:text-base text-purple-900 mb-1 sm:mb-2">Pro Tip</h4>
                  <p className="text-xs sm:text-sm text-purple-700">
                    Be specific with your topic and add context for better AI responses. The more details, the better the output!
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </aside>
    </>
  );
}
