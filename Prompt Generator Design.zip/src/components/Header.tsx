import { Globe, Menu, Sparkles, User } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import logoImage from 'figma:asset/cd0514a7a2b05084f9e24d2bd4801fa7c9cc036a.png';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Button } from './ui/button';

interface HeaderProps {
  language: string;
  onLanguageChange: (language: string) => void;
  onMenuToggle: () => void;
  onLoginClick?: () => void;
  isLoggedIn?: boolean;
  userName?: string;
}

export function Header({ language, onLanguageChange, onMenuToggle, onLoginClick, isLoggedIn, userName }: HeaderProps) {

  const languages = [
    'English',
    'Spanish',
    'French',
    'German',
    'Chinese',
    'Japanese',
    'Korean',
    'Portuguese',
    'Russian',
    'Arabic',
    'Hindi',
    'Italian'
  ];

  return (
    <header className="bg-white/80 backdrop-blur-lg border-b border-purple-200 sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4 py-3 sm:py-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={onMenuToggle}
            className="lg:hidden text-purple-600 hover:bg-purple-100 p-2"
          >
            <Menu className="w-5 h-5" />
          </Button>
          
          <ImageWithFallback 
            src={logoImage} 
            alt="MuseForge Logo" 
            className="w-10 h-10 sm:w-12 sm:h-12 rounded-full flex-shrink-0 object-cover"
            fallback={
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
            }
          />
          <div className="min-w-0">
            <h1 className="text-purple-900 truncate">MuseForge</h1>
            <p className="text-xs sm:text-sm text-purple-600 hidden sm:block">AI Prompt Generator</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 sm:w-5 sm:h-5 text-purple-600 flex-shrink-0 hidden sm:block" />
          <Select value={language} onValueChange={onLanguageChange}>
            <SelectTrigger className="w-[100px] sm:w-[180px] border-purple-200 focus:ring-purple-500 text-sm">
              <SelectValue placeholder="Language" />
            </SelectTrigger>
            <SelectContent>
              {languages.map((lang) => (
                <SelectItem key={lang} value={lang}>
                  {lang}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          {/* User Icon/Profile */}
          {isLoggedIn ? (
            <Button
              variant="ghost"
              size="sm"
              onClick={onLoginClick}
              className="text-purple-600 hover:bg-purple-100 p-2 flex items-center gap-2"
            >
              <User className="w-5 h-5" />
              <span className="hidden md:inline text-sm">{userName}</span>
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              onClick={onLoginClick}
              className="text-purple-600 hover:bg-purple-100 p-2"
              title="Login"
            >
              <User className="w-5 h-5" />
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}