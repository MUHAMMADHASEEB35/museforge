import { useState } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Footer } from './components/Footer';
import { PromptGenerator } from './components/PromptGenerator';
import { LoginPage } from './components/LoginPage';
import { Toaster } from 'sonner@2.0.3';

export interface SavedPrompt {
  id: string;
  platform: string;
  topic: string;
  prompt: string;
  timestamp: Date;
  isFavorite: boolean;
}

export default function App() {
  const [language, setLanguage] = useState('English');
  const [savedPrompts, setSavedPrompts] = useState<SavedPrompt[]>([]);
  const [currentView, setCurrentView] = useState<'generator' | 'history' | 'favorites'>('generator');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');

  const addPromptToHistory = (prompt: SavedPrompt) => {
    setSavedPrompts(prev => [prompt, ...prev].slice(0, 50));
  };

  const toggleFavorite = (id: string) => {
    setSavedPrompts(prev =>
      prev.map(p => p.id === id ? { ...p, isFavorite: !p.isFavorite } : p)
    );
  };

  const deletePrompt = (id: string) => {
    setSavedPrompts(prev => prev.filter(p => p.id !== id));
  };

  const handleViewChange = (view: 'generator' | 'history' | 'favorites') => {
    setCurrentView(view);
    setIsSidebarOpen(false);
  };

  const handleLogin = (email: string, name: string) => {
    setIsLoggedIn(true);
    setUserEmail(email);
    setUserName(name);
  };

  const handleLoginClick = () => {
    if (isLoggedIn) {
      // If already logged in, clicking shows a logout option or profile
      // For now, we'll just log them out
      setIsLoggedIn(false);
      setUserName('');
      setUserEmail('');
    }
  };

  // Show login page if not logged in
  if (!isLoggedIn) {
    return (
      <>
        <Toaster position="bottom-right" theme="light" />
        <LoginPage onLogin={handleLogin} />
      </>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-violet-50 via-purple-50 to-indigo-50">
      <Toaster position="bottom-right" theme="light" />
      
      <Header 
        language={language} 
        onLanguageChange={setLanguage}
        onMenuToggle={() => setIsSidebarOpen(!isSidebarOpen)}
        onLoginClick={handleLoginClick}
        isLoggedIn={isLoggedIn}
        userName={userName}
      />
      
      <div className="flex flex-1">
        {isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-30 lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}
        
        <Sidebar
          currentView={currentView}
          onViewChange={handleViewChange}
          savedPrompts={savedPrompts}
          onToggleFavorite={toggleFavorite}
          onDeletePrompt={deletePrompt}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
        />
        
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          <PromptGenerator
            language={language}
            currentView={currentView}
            savedPrompts={savedPrompts}
            onAddPrompt={addPromptToHistory}
            onToggleFavorite={toggleFavorite}
            onDeletePrompt={deletePrompt}
          />
        </main>
      </div>
      
      <Footer />
    </div>
  );
}