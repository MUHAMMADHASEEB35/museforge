
  # Prompt Generator Design

  This is a code bundle for Prompt Generator Design. The original project is available at https://www.figma.com/design/5rS9RBA8Shl5HXMQFWCigg/Prompt-Generator-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  